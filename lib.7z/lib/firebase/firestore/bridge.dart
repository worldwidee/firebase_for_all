import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_for_all/firebase_for_all.dart';
import 'package:firedart/firedart.dart' as firedart;

import '../../functions.dart';
import 'models.dart';
import 'original.dart';
import 'windows.dart';

Future<QuerySnapshotForAll> getCollections(ColRef ref,
    {required QueryProperties queryProperties}) async {
  if (isWindows()) {
    return (await getCollectionsWindows(ref._reference,
        queryProperties: queryProperties, colRef: ref));
  } else {
    return (await getCollectionsOriginal(ref._reference!,
        queryProperties: queryProperties, colRef: ref));
  }
}

Future<DocumentSnapshotForAll> getDoc(DocRef ref) async {
  if (isWindows()) {
    return (await getDocumentWindows(ref._reference, docRef: ref));
  } else {
    return (await getDocumentOriginal(ref._reference, docRef: ref));
  }
}

class FirestoreItem {
  ColRef collection(String collection) {
    return ColRef.withReference(isValid()
        ? instanceFirestoreOriginal().collection(collection)
        : instanceFirestoreWindows().collection(collection));
  }
}

class FirestoreConverter<T extends Object?> {
  T Function(DocumentSnapshotForAll, dynamic) fromFirestore;
  Map<String, Object?> Function(T, dynamic) toFirestore;

  FirestoreConverter({required this.toFirestore, required this.fromFirestore});
}

class ColRef {
  firedart.CollectionReference? _ref_windows;
  CollectionReference<Map<String, dynamic>>? _ref_original;
  QueryProperties _queryProperties = QueryProperties();
  get _reference => _ref_windows ?? _ref_original;
  FirestoreConverter? _converter;
  FirestoreConverter? get converter=>_converter;
  ColRef.withReference(dynamic reference) {
    if (reference is CollectionReference<Map<String, dynamic>>) {
      _ref_original = reference;
    } else {
      _ref_windows = reference;
    }
  }
  ColRef._withQuery(
    dynamic reference, {
    required QueryProperties queryProperties,
    required FirestoreConverter? converter,
  }) {
    if (reference is CollectionReference<Map<String, dynamic>>) {
      _ref_original = reference;
    } else {
      _ref_windows = reference;
    }
    _queryProperties = queryProperties;
    _converter = converter;
  }

  ColRef withConverter<R extends Object?>(
      {required R Function(DocumentSnapshotForAll, dynamic)
          fromFirestore,
      required Map<String, Object?> Function(R, dynamic) toFirestore}) {
    _converter = FirestoreConverter<R>(
        toFirestore: toFirestore, fromFirestore: fromFirestore);
    return this;
  }

  ColRef limit(int limit) {
    _queryProperties.limit = limit;
    return _copyWithQuery;
  }

  ColRef limitToLast(int limitToLast) {
    _queryProperties.limitToLast = limitToLast;
    return _copyWithQuery;
  }

  ColRef startAt(List<Object?> values) {
    _queryProperties.startAt = values;
    return _copyWithQuery;
  }

  ColRef endAt(List<Object?> values) {
    _queryProperties.endAt = values;
    return _copyWithQuery;
  }

  ColRef startAfter(List<Object?> values) {
    _queryProperties.startAfter = values;
    return _copyWithQuery;
  }

  ColRef endBefore(List<Object?> values) {
    _queryProperties.endBefore = values;
    return _copyWithQuery;
  }

  ColRef startAfterDocument(DocumentSnapshotForAll documentSnapshot) {
    _queryProperties.startAfterDocument = documentSnapshot;
    return _copyWithQuery;
  }

  ColRef startAtDocument(DocumentSnapshotForAll documentSnapshot) {
    _queryProperties.startAtDocument = documentSnapshot;
    return _copyWithQuery;
  }

  ColRef endAtDocument(DocumentSnapshotForAll documentSnapshot) {
    _queryProperties.endAtDocument = documentSnapshot;
    return _copyWithQuery;
  }

  ColRef endBeforeDocument(DocumentSnapshotForAll documentSnapshot) {
    _queryProperties.endBeforeDocument = documentSnapshot;
    return _copyWithQuery;
  }

  ColRef where(
    String fieldPath, {
    dynamic isEqualTo,
    dynamic isNotEqualTo,
    dynamic isLessThan,
    dynamic isLessThanOrEqualTo,
    dynamic isGreaterThan,
    dynamic isGreaterThanOrEqualTo,
    dynamic arrayContains,
    List<dynamic>? arrayContainsAny,
    List<dynamic>? whereIn,
    List<dynamic>? whereNotIn,
    bool isNull = false,
  }) {
    _queryProperties.whereQuerys.add(WhereQuery(
        document: fieldPath,
        isEqualTo: isEqualTo,
        isNotEqualTo: isNotEqualTo,
        isLessThan: isLessThan,
        isLessThanOrEqualTo: isLessThanOrEqualTo,
        isGreaterThan: isGreaterThan,
        isGreaterThanOrEqualTo: isGreaterThanOrEqualTo,
        arrayContains: arrayContains,
        arrayContainsAny: arrayContainsAny,
        whereIn: whereIn,
        whereNotIn: whereNotIn,
        isNull: isNull));
    return _copyWithQuery;
  }

  ColRef orderBy(String fieldPath, {bool descending = false}) {
    _queryProperties.orderByQuerys
        .add(OrderByQuery(fieldPath, descending: descending));
    return _copyWithQuery;
  }

  ColRef get _copyWithQuery {
    return ColRef._withQuery(_ref_windows ?? _ref_original,
        queryProperties: _queryProperties, converter: _converter);
  }

  CollectionSnapshots snapshots() {
    if (_ref_windows != null) {
      return CollectionSnapshots(_ref_windows!);
    } else {
      return CollectionSnapshots(_ref_original);
    }
  }

  DocRef doc(String id) {
    return DocRef.withReference(_ref_windows != null
        ? _ref_windows!.document(id)
        : _ref_original!.doc(id));
  }

  Future<QuerySnapshotForAll> get() async {
    return (await getCollections(this, queryProperties: _queryProperties));
  }
}

class DocRef {
  firedart.DocumentReference? _ref_windows;
  DocumentReference<Map<String, dynamic>>? _ref_original;

  FirestoreConverter? _converter;
  FirestoreConverter? get converter=>_converter;
  get _reference => _ref_windows ?? _ref_original;

  DocRef.withReference(dynamic reference, {FirestoreConverter? converter}) {
    if (reference is firedart.DocumentReference) {
      _ref_windows = reference;
    } else {
      _ref_original = reference;
    }
    _converter = converter;
  }
  
  DocRef withConverter<R extends Object?>(
      {required R Function(DocumentSnapshotForAll, dynamic)
          fromFirestore,
      required Map<String, Object?> Function(R, dynamic) toFirestore}) {
    _converter = FirestoreConverter<R>(
        toFirestore: toFirestore, fromFirestore: fromFirestore);
    return this;
  }

  Future<DocumentSnapshotForAll> get() async {
    return (await getDoc(this));
  }

  DocumentSnapshots snapshots() {
    if (_ref_windows != null) {
      return DocumentSnapshots(_ref_windows!);
    } else {
      return DocumentSnapshots(_ref_original);
    }
  }

  ColRef collection(String collection) {
    return _ref_windows != null
        ? ColRef.withReference(_ref_windows!.collection(collection))
        : ColRef.withReference(_ref_original!.collection(collection));
  }

  Future<void> set(Map<String, dynamic> map) async {
    if (_ref_windows != null) {
      await _ref_windows!.set(map);
    } else {
      await _ref_original!.set(map);
    }
  }

  Future<void> update(Map<String, dynamic> map) async {
    if (_ref_windows != null) {
      await _ref_windows!.update(map);
    } else {
      await _ref_original!.update(map);
    }
  }

  Future<void> delete() async {
    if (_ref_windows != null) {
      await _ref_windows!.delete();
    } else {
      await _ref_original!.delete();
    }
  }
}


//todo: withConverter'ı becermeye çalış
//todo: collection'a add fonksiyonu ekle