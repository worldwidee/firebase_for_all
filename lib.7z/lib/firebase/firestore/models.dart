import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_for_all/firebase/firestore/bridge.dart';
import 'package:firedart/firedart.dart' as firedart;
import 'package:flutter/widgets.dart';

class CollectionSnapshots {
  CollectionReference? _reference_original;
  firedart.CollectionReference? _reference_windows;
  CollectionSnapshots(dynamic reference) {
    if (reference is firedart.CollectionReference) {
      _reference_windows = reference;
    } else {
      _reference_original = reference;
    }
  }
  StreamSubscription<dynamic>? _stream;
  listen(
    void Function(QuerySnapshotForAll)? onData, {
    Function? onError,
    void Function()? onDone,
    bool? cancelOnError,
  }) {
    if (_reference_original != null) {
      _stream = _reference_original!.snapshots().listen(
        (event) {
          if (onData != null) {
            List<DocumentSnapshotForAll> docs = [];
            if (event.size > 0) {
              docs = event.docs
                  .map((e) => DocumentSnapshotForAll(
                      e.data() != null
                          ? e.data() as Map<String, dynamic>
                          : null,
                      e.id,
                      "${_reference_original!.path}\\${e.id}",
                      DocRef.withReference(e.reference)))
                  .toList();
            }
            onData(QuerySnapshotForAll(docs, docChanges: event.docChanges));
          }
        },
        onError: (e, stacktrace) {
          print("type:${e.runtimeType}");
        },
        onDone: onDone,
        cancelOnError: cancelOnError,
      );
    } else {
      _stream = _reference_windows!.stream.listen(
        (event) {
          print("hahah");
          if (onData != null) {
            List<DocumentSnapshotForAll> docs = [];
            if (event.isNotEmpty) {
              docs = List<DocumentSnapshotForAll>.from(event.map((e) =>
                  DocumentSnapshotForAll(
                      e.map,
                      e.id,
                      "${_reference_windows!.path}\\${e.id}",
                      DocRef.withReference(e.reference))));
            }
            onData(QuerySnapshotForAll(docs, docChanges: []));
          }
        },
        onError: (e, stacktrace) {
          print("zort");
          print("type:${e.runtimeType}");
        },
        onDone: onDone,
        cancelOnError: cancelOnError,
      );
    }
  }

  Future<void> cancel() async {
    if (_stream != null) {
      await _stream!.cancel();
    }
  }

  void pause() async {
    if (_stream != null) {
      _stream!.pause();
    }
  }

  void resume() async {
    if (_stream != null) {
      _stream!.resume();
    }
  }

  bool get isPaused => _stream!.isPaused;
}

class DocumentSnapshots {
  DocumentReference? _reference_original;
  firedart.DocumentReference? _reference_windows;
  DocumentSnapshots(dynamic reference) {
    if (reference is firedart.DocumentReference) {
      _reference_windows = reference;
    } else {
      _reference_original = reference;
    }
  }
  StreamSubscription<dynamic>? _stream;
  listen(
    void Function(DocumentSnapshotForAll)? onData, {
    Function? onError,
    void Function()? onDone,
    bool? cancelOnError,
  }) {
    if (_reference_original != null) {
      _stream = _reference_original!.snapshots().listen(
        (event) {
          if (onData != null) {
            onData(DocumentSnapshotForAll(
                event.data() != null
                    ? event.data() as Map<String, dynamic>
                    : null,
                event.id,
                _reference_original!.path,
                DocRef.withReference(_reference_original)));
          }
        },
        onError: onError,
        onDone: onDone,
        cancelOnError: cancelOnError,
      );
    } else {
      _stream = _reference_windows!.stream.listen(
        (event) {
          if (onData != null && event != null) {
            onData(DocumentSnapshotForAll(
                event.map,
                event.id,
                _reference_windows!.path,
                DocRef.withReference(_reference_windows)));
          }
        },
        onError: onError,
        onDone: onDone,
        cancelOnError: cancelOnError,
      );
    }
  }

  Future<void> cancel() async {
    if (_stream != null) {
      await _stream!.cancel();
    }
  }

  void pause() async {
    if (_stream != null) {
      _stream!.pause();
    }
  }

  void resume() async {
    if (_stream != null) {
      _stream!.resume();
    }
  }

  bool get isPaused => _stream!.isPaused;
}

class QuerySnapshotForAll {
  QuerySnapshotForAll(this._docs, {required List<DocumentChange> docChanges}) {
    _docChanges = docChanges;
  }

  List<DocumentSnapshotForAll> _docs = [];

  List<DocumentChange> _docChanges = [];

  List<DocumentSnapshotForAll> get docs => _docs;

  List<DocumentChange> get docChanges => _docChanges;

  int get size => _docs.length;

  bool get exists => _docs.isNotEmpty;
}

class DocumentSnapshotForAll {
  String id;
  DocumentSnapshotForAll(this._data, this.id, this.path, this.ref);
  Map<String, dynamic>? _data;
  String path;
  DocRef ref;

  dynamic operator [](String key) {
    if (_data == null || !_data!.containsKey(key)) return null;
    return _data![key];
  }

  bool get exists => _data != null;
  Map<String, dynamic>? get map=>_data;
  data() {
    if(ref.converter!=null){
      return ref.converter!.fromFirestore(this,null);
    }else{
      return _data;
    }
  }
}

class SnapshotState<T> {
  final ConnectionState connectionState;

  const SnapshotState._(
      this.connectionState, this.data, this.error, this.stackTrace)
      : assert(connectionState != null),
        assert(!(data != null && error != null)),
        assert(stackTrace == null || error != null);

  const SnapshotState.nothing()
      : this._(ConnectionState.none, null, null, null);

  const SnapshotState.waiting()
      : this._(ConnectionState.waiting, null, null, null);

  const SnapshotState.done() : this._(ConnectionState.done, null, null, null);

  const SnapshotState.withData(ConnectionState state, T data)
      : this._(state, data, null, null);

  const SnapshotState.withError(
    ConnectionState state,
    Object error, [
    StackTrace stackTrace = StackTrace.empty,
  ]) : this._(state, null, error, stackTrace);

  final T? data;

  T get requireData {
    if (hasData) return data!;
    if (hasError) Error.throwWithStackTrace(error!, stackTrace!);
    throw StateError('Snapshot has neither data nor error');
  }

  bool get hasData => data != null;
  bool get isWaiting => connectionState == ConnectionState.waiting;
  bool get hasError => error != null;
  final Object? error;
  final StackTrace? stackTrace;
}

class WhereQuery {
  String document;
  dynamic isEqualTo,
      isLessThan,
      isLessThanOrEqualTo,
      isGreaterThan,
      isGreaterThanOrEqualTo,
      arrayContains,isNotEqualTo;
  List<dynamic>? arrayContainsAny;
  List<dynamic>? whereIn;
  List<dynamic>? whereNotIn;
  bool? isNull;
  WhereQuery({
    required this.document,
    this.isEqualTo,
    this.isNotEqualTo,
    this.isLessThan,
    this.isLessThanOrEqualTo,
    this.isGreaterThan,
    this.isGreaterThanOrEqualTo,
    this.arrayContains,
    this.arrayContainsAny,
    this.whereIn,
    this.whereNotIn,
    this.isNull,
  });
}

class OrderByQuery {
  String fieldPath;
  bool descending;

  OrderByQuery(this.fieldPath, {this.descending = false});
}


class QueryProperties{
  
  List<WhereQuery> whereQuerys = [];
  List<OrderByQuery> orderByQuerys = [];
  int? limit, limitToLast;
  List<Object?> startAt = [];
  List<Object?> endAt = [];
  List<Object?> startAfter = [];
  List<Object?> endBefore = [];
  DocumentSnapshotForAll? startAfterDocument;
  DocumentSnapshotForAll? startAtDocument;
  DocumentSnapshotForAll? endAtDocument;
  DocumentSnapshotForAll? endBeforeDocument;
} 

