import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

import 'models.dart';

class CollectionBuilder extends StatefulWidget {
  CollectionSnapshots stream;
  Widget Function(BuildContext, AsyncSnapshot<QuerySnapshotForAll>) builder;
  CollectionBuilder({Key? key, required this.stream, required this.builder})
      : super(key: key);

  @override
  State<CollectionBuilder> createState() =>
      _CollectionBuilderState(stream, builder);
}

class _CollectionBuilderState extends State<CollectionBuilder> {
  CollectionSnapshots stream;
  Widget Function(BuildContext, AsyncSnapshot<QuerySnapshotForAll>) builder;
  SnapshotState? state;
  _CollectionBuilderState(this.stream, this.builder) {
    state = const SnapshotState.waiting();
  }

  @override
  void initState() {
    widget.stream.listen((event) {
      state = SnapshotState.withData(ConnectionState.active, event);
      setState(() {});
    }, onError: (error, stackTrace) {
      state =
          SnapshotState.withError(ConnectionState.active, error, stackTrace);
      setState(() {});
    });
    super.initState();
  }

  @override
  void dispose() {
    widget.stream.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (state!.hasData) {
      return builder(
          context, AsyncSnapshot.withData(state!.connectionState, state!.data));
    } else if (state!.hasError) {
      return builder(
          context,
          AsyncSnapshot.withError(state!.connectionState, state!.error!,
              state!.stackTrace ?? StackTrace.empty));
    } else if (state!.isWaiting) {
      return builder(context, const AsyncSnapshot.waiting());
    } else {
      return builder(context, const AsyncSnapshot.nothing());
    }
  }
}

class DocumentBuilder extends StatefulWidget {
  DocumentSnapshots stream;
  Widget Function(BuildContext, AsyncSnapshot<DocumentSnapshotForAll>) builder;
  DocumentBuilder({Key? key, required this.stream, required this.builder})
      : super(key: key);

  @override
  State<DocumentBuilder> createState() =>
      _DocumentBuilderState(stream, builder);
}

class _DocumentBuilderState extends State<DocumentBuilder> {
  DocumentSnapshots stream;
  Widget Function(BuildContext, AsyncSnapshot<DocumentSnapshotForAll>) builder;
  SnapshotState? state;
  _DocumentBuilderState(this.stream, this.builder) {
    state = const SnapshotState.waiting();
  }

  @override
  void initState() {
    widget.stream.listen((event) {
      state = SnapshotState.withData(ConnectionState.active, event);
      setState(() {});
    }, onError: (error, stackTrace) {
      state =
          SnapshotState.withError(ConnectionState.active, error, stackTrace);
      setState(() {});
    });
    super.initState();
  }

  @override
  void dispose() {
    widget.stream.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (state!.hasData) {
      return builder(
          context, AsyncSnapshot.withData(state!.connectionState, state!.data));
    } else if (state!.hasError) {
      return builder(
          context,
          AsyncSnapshot.withError(state!.connectionState, state!.error!,
              state!.stackTrace ?? StackTrace.empty));
    } else if (state!.isWaiting) {
      return builder(context, const AsyncSnapshot.waiting());
    } else {
      return builder(context, const AsyncSnapshot.nothing());
    }
  }
}

