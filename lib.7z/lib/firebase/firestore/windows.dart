import 'package:firedart/firedart.dart';
import 'package:get/get.dart';
import '../../../firebase_for_all.dart';
import 'bridge.dart';

Future<void> initFirestoreWindows() async {
  if (Get.find<FirebaseControlPanel>().options != null) {
    Firestore.initialize(Get.find<FirebaseControlPanel>().options!.projectId);
  } else {
    print("FirebaseOptions cant be null!!");
  }
}

Firestore instanceFirestoreWindows() {
  return Firestore.instance;
}

Future<QuerySnapshotForAll> getCollectionsWindows(CollectionReference ref,
    {required QueryProperties queryProperties, required ColRef colRef}) async {
  dynamic init = ref;
  for (var query in queryProperties.whereQuerys) {
    init = init.where(
      query.document,
      isEqualTo: query.isEqualTo,
      isNotEqualTo: query.isNotEqualTo,
      isLessThan: query.isLessThan,
      isLessThanOrEqualTo: query.isLessThanOrEqualTo,
      isGreaterThan: query.isGreaterThan,
      isGreaterThanOrEqualTo: query.isGreaterThanOrEqualTo,
      arrayContains: query.arrayContains,
      arrayContainsAny: query.arrayContainsAny,
      whereIn: query.whereIn,
      whereNotIn: query.whereNotIn,
      isNull: query.isNull,
    );
  }
  for (var query in queryProperties.orderByQuerys) {
    init = init.orderBy(
      query.fieldPath,
      descending: query.descending,
    );
  }
  if(queryProperties.limit!=null){
    init=init.limit(queryProperties.limit);
  }
  late QuerySnapshotForAll snapshots;
  await init.get().then((value) {
    if (value.isNotEmpty) {
      snapshots = QuerySnapshotForAll(
          List<DocumentSnapshotForAll>.from(value
              .map((element) => DocumentSnapshotForAll(element.map, element.id,
                  init.path + "\\" + element.id, colRef.doc(element.id)))
              .toList()),
          docChanges: []);
    } else {
      snapshots = QuerySnapshotForAll([], docChanges: []);
    }
  });
  return snapshots;
}

Future<DocumentSnapshotForAll> getDocumentWindows(DocumentReference ref,
    {required DocRef docRef}) async {
  late DocumentSnapshotForAll doc;
  await ref.get().then((value) {
    print(value);
    doc = DocumentSnapshotForAll(value.map, value.id, value.id, docRef);
  });
  return doc;
}
