import 'dart:async';

import 'dart:io';
import 'dart:typed_data';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_dart/firebase_dart.dart' as firebase_dart;

import '../../functions.dart';
import '../../functions.dart' as functions;
import 'models.dart';
import 'original.dart';
import 'original.dart' as original;
import 'windows.dart';

class StorageRef {
  firebase_dart.Reference? _ref_windows;
  Reference? _ref_original;

  StorageRef.withReference(dynamic reference) {
    if (reference is firebase_dart.Reference) {
      _ref_windows = reference;
    } else {
      _ref_original = reference;
    }
  }

  Future<FullMetadataForAll> getMetadata() async {
    if (_ref_original != null) {
      var metadata = await _ref_original!.getMetadata();
      return FullMetadataForAll.withMetadata(metadata);
    } else {
      var metadata = await _ref_windows!.getMetadata();
      return FullMetadataForAll.withMetadata(metadata);
    }
  }

  UploadTaskForAll putData(Uint8List data, [SettableMetadata? metadata]) {
    if (_ref_original != null) {
      return UploadTaskForAll.withTask(_ref_original!.putData(data));
    } else {
      return UploadTaskForAll.withTask(_ref_windows!.putData(data));
    }
  }

  Future<void> delete() async {
    if (_ref_original != null) {
      await _ref_original!.delete();
    } else {
      await _ref_windows!.delete();
    }
  }

  //StorageRef get root=>
  Future<void> deleteFiles() async {
    if (_ref_original != null) {
      await deleteFilesOriginal(_ref_original!);
    } else {
      await deleteFilesWindows(_ref_windows!);
    }
  }

  Future<int> getSize() async {
    int size = 0;
    try {
      await getMetadata().then((value) => size = value.size!);
    } catch (e) {}
    return size;
  }

  Future<int> getDirSize() async {
    int size = 0;
    try {
      ListResultForAll result = await listAll();
      for (var item in result.items) {
        size += await getSize();
      }
      var dirs = result.prefixes;
      for (var dir in dirs) {
        size += await getDirSize();
      }
    } catch (e) {
      print(e);
      return -1;
    }
    return size;
  }

  Future<String> getDownloadURL() async {
    if (_ref_original != null) {
      return await _ref_original!.getDownloadURL();
    } else {
      return await _ref_windows!.getDownloadURL();
    }
  }

  Future<Uint8List?> getData() async {
    if (_ref_original != null) {
      return await _ref_original!.getData();
    } else {
      return await _ref_windows!.getData();
    }
  }

  Future<DownloadTaskForAll?> writeToFile(File file) async {
    if (_ref_original != null) {
      return original.writeToFile(file, _ref_original!);
    } else {
      String url = await getDownloadURL();
      return (await functions.downloadFile(url, file: file));
    }
  }

  Future<DownloadTaskForAll?> downloadFile() async {
    String url = await getDownloadURL();
    return (await functions.downloadFile(url));
  }

  Future<ListResultForAll> listAll() async {
    if (_ref_original != null) {
      return await listAllOriginal(_ref_original!);
    } else {
      return await listAllWindows(_ref_windows!);
    }
  }

  Future<List<StorageFile>> scan() async {
    List<StorageFile> files = [];
    try {
      ListResultForAll result = await listAll();
      for (var item in result.items) {
        await child(item.name).getMetadata().then((value) => files.add(
            StorageFile(
                cloudPath: "${this.fullPath}/${item.name}",
                fileName: item.name,
                reference: item,
                size: value.size!)));
      }
      var dirs = result.prefixes;
      for (var dir in dirs) {
        files.addAll((await this.child(dir.name).scan()));
      }
    } catch (e) {}
    return files;
  }

  Future<List<StorageFile>> getFiles() async {
    List<StorageFile> files = [];
    ListResultForAll result = await listAll();
    for (var item in result.items) {
      await child(item.name).getMetadata().then((value) => files.add(
          StorageFile(
              cloudPath: "$fullPath/${item.name}",
              fileName: item.name,
              reference: item,
              size: value.size!)));
    }
    return files;
  }

  Future<List<StorageDirectory>> getDirectories() async {
    List<StorageDirectory> directories = [];
    ListResultForAll result = await listAll();
    var dirs = result.prefixes;
    for (var dir in dirs) {
      directories.add(StorageDirectory(
          cloudPath: "$fullPath/${dir.name}",
          dirName: dir.name,
          reference: dir));
    }
    return directories;
  }

  StorageRef child(String ref) {
    return StorageRef.withReference(_ref_windows != null
        ? _ref_windows!.child(ref)
        : _ref_original!.child(ref));
  }

  String get name {
    if (_ref_original != null) {
      return _ref_original!.name;
    } else {
      return _ref_windows!.name;
    }
  }

  String get bucket {
    if (_ref_original != null) {
      return _ref_original!.bucket;
    } else {
      return _ref_windows!.bucket;
    }
  }

  String get fullPath {
    if (_ref_original != null) {
      return _ref_original!.fullPath;
    } else {
      return _ref_windows!.fullPath;
    }
  }

  @override
  String toString() {
    if (_ref_original != null) {
      return _ref_original!.toString();
    } else {
      return _ref_windows!.toString();
    }
  }

  StorageRef get parent {
    return StorageRef.withReference(
        _ref_windows != null ? _ref_windows!.parent : _ref_original!.parent);
  }

  StorageRef get root {
    return StorageRef.withReference(
        _ref_windows != null ? _ref_windows!.root : _ref_original!.root);
  }
}

class StorageDirectory {
  String cloudPath;
  String dirName;
  StorageRef reference;
  List<String> relatedDirs = [];
  StorageDirectory(
      {required this.cloudPath,
      required this.dirName,
      required this.reference}) {
    List<String> names = cloudPath.split("/");
    if (names.length > 6) {
      relatedDirs = [];
      for (int i = 6; i < names.length - 1; i++) {
        relatedDirs.add(names[i]);
      }
    }
  }
}

class StorageFile {
  String cloudPath;
  String fileName;
  StorageRef reference;
  late String type, extension;
  List<String> relatedDirs = [];
  int size;
  StorageFile(
      {required this.cloudPath,
      required this.fileName,
      required this.size,
      required this.reference}) {
    List<String> names = cloudPath.split("/");
    if (names.length > 6) {
      relatedDirs = [];
      for (int i = 6; i < names.length - 1; i++) {
        relatedDirs.add(names[i]);
      }
    }
    extension = fileName.split(".").last.toUpperCase();
    if (imgExt.any((element) => element.toUpperCase() == extension)) {
      type = "image";
    } else if (vidExt.any((element) => element.toUpperCase() == extension)) {
      type = "video";
    } else {
      type = "file";
    }
  }
}

class FirebaseStorageItem {
  FirebaseStorageItem? instance() {
    return this;
  }

  StorageRef ref(String reference) {
    return StorageRef.withReference(isValid()
        ? instanceStorageOriginal().ref(reference)
        : instanceStorageWindows().ref(reference));
  }
}

class ListResultForAll {
  List<StorageRef> _items;
  List<StorageRef> _prefixes;
  ListResultForAll(this._items, this._prefixes);

  List<StorageRef> get items => _items;
  List<StorageRef> get prefixes => _prefixes;
}

class FullMetadataForAll {
  firebase_dart.FullMetadata? _metadata_windows;
  FullMetadata? _metadata_original;

  FullMetadataForAll.withMetadata(dynamic metadata) {
    if (metadata is firebase_dart.FullMetadata) {
      _metadata_windows = metadata;
    } else {
      _metadata_original = metadata;
    }
  }

  get _metadata {
    if (_metadata_windows != null) {
      return _metadata_windows;
    } else {
      return _metadata_original;
    }
  }

  String? get bucket {
    return _metadata.bucket;
  }

  String? get cacheControl {
    return _metadata.cacheControl;
  }

  String? get contentDisposition {
    return _metadata.contentDisposition;
  }

  String? get contentEncoding {
    return _metadata.contentEncoding;
  }

  String? get contentLanguage {
    return _metadata.contentLanguage;
  }

  String? get contentType {
    return _metadata.contentType;
  }

  Map<String, String>? get customMetadata {
    return _metadata.customMetadata;
  }

  String get fullPath {
    return _metadata.fullPath;
  }

  String? get generation {
    return _metadata.generation;
  }

  String? get metadataGeneration {
    return _metadata.metadataGeneration;
  }

  String? get md5Hash {
    return _metadata.md5Hash;
  }

  String? get metageneration {
    return _metadata.metageneration;
  }

  String get name {
    return _metadata.name;
  }

  int? get size {
    return _metadata.size;
  }

  DateTime? get timeCreated {
    return _metadata.timeCreated;
    ;
  }

  DateTime? get updated {
    return _metadata.updated;
  }
}
