import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_dart/firebase_dart.dart' as firebase_dart;

class UploadTaskForAll {
  firebase_dart.UploadTask? _windowsTask;
  UploadTask? _originalTask;

  UploadTaskForAll.withTask(dynamic task) {
    print(task.runtimeType);
    if (task.runtimeType == UploadTask) {
      _originalTask = task;
    } else {
      _windowsTask = task;
    }
  }
  Future<void> await() async {
    if (_originalTask != null) {
      await _originalTask;
    } else {
      await _windowsTask;
    }
  }

  Future<void> awaitTask() async {
    if (_originalTask != null) {
      await _originalTask;
    } else {
      await _windowsTask;
    }
  }

  Future<void> cancel() async {
    if (_originalTask != null) {
      await _originalTask!.cancel();
    } else {
      await _windowsTask!.cancel();
    }
  }

  Future<void> pause() async {
    if (_originalTask != null) {
      await _originalTask!.pause();
    } else {
      await _windowsTask!.pause();
    }
  }

  Future<void> resume() async {
    if (_originalTask != null) {
      await _originalTask!.resume();
    } else {
      await _windowsTask!.resume();
    }
  }

  Future<void> stop() async {
    if (_originalTask != null) {
      await _originalTask!.resume();
    } else {
      await _windowsTask!.resume();
    }
  }

  listen(
    void Function(dynamic)? onData, {
    Function? onError,
    void Function()? onDone,
    bool? cancelOnError,
  }) {
    if (_originalTask != null) {
      _originalTask!.snapshotEvents.listen(onData,
          onError: onError, onDone: onDone, cancelOnError: cancelOnError);
    } else {
      _windowsTask!.snapshotEvents.listen(onData,
          onError: onError, onDone: onDone, cancelOnError: cancelOnError);
    }
  }
}
