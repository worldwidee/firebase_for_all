import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import '../../functions.dart';
import '../../functions.dart' as functions;
import 'bridge.dart';

FirebaseStorage instanceStorageOriginal() {
  return FirebaseStorage.instance;
}

Future<DownloadTaskForAll?> writeToFile(File file, Reference ref) async {
  DownloadTaskForAll task = DownloadTaskForAll(targetFile: file);
  DownloadTask originalTask = ref.writeToFile(file);
  task.setDownloadingStream =
      originalTask.snapshotEvents.listen((taskSnapshot) {
    int byte = taskSnapshot.bytesTransferred;
    int total = taskSnapshot.metadata?.size ?? 0;
    switch (taskSnapshot.state) {
      case firebase_storage.TaskState.running:
        task.updateTask(ProcessTask(
            processed: taskSnapshot.bytesTransferred,
            total: total,
            state: functions.TaskState.running));
        break;
      case firebase_storage.TaskState.paused:
        break;
      case firebase_storage.TaskState.success:
        task.updateTask(ProcessTask(
            processed: taskSnapshot.bytesTransferred,
            total: total,
            state: functions.TaskState.success));
        break;
      case firebase_storage.TaskState.canceled:
        break;
      case firebase_storage.TaskState.error:
        break;
    }
  }, onError: (e, stackTrace) {
    task.addError(e, stackTrace);
  });
}

Future<ListResultForAll> listAllOriginal(Reference ref) async {
  Reference reference = ref;
  ListResult originalResult = await reference.listAll();
  return ListResultForAll(
      originalResult.items.map((e) => StorageRef.withReference(e)).toList(),
      originalResult.prefixes.map((e) => StorageRef.withReference(e)).toList());
}

Future<void> deleteFilesOriginal(Reference ref) async {
  Reference reference = ref;
  ListResult result = await reference.listAll();
  for (var item in result.items) {
    await ref.child(item.name).delete();
  }
  var dirs = result.prefixes;
  for (var dir in dirs) {
    await deleteFilesOriginal(reference.child(dir.name));
  }
}
