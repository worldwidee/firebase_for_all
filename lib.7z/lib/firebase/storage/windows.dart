import 'package:firebase_dart/firebase_dart.dart';
import 'package:get/get.dart';
import '../../../firebase_for_all.dart';
import 'bridge.dart';

Future<dynamic> initStorageWindows() async {
  FirebaseDart.setup(storagePath: 'users/');
  var options = Get.find<FirebaseControlPanel>().options!;
  await Firebase.initializeApp(
      options: FirebaseOptions(
          apiKey: options.apiKey,
          authDomain: options.authDomain,
          projectId: options.projectId,
          storageBucket: options.storageBucket,
          messagingSenderId: options.messagingSenderId,
          appId: options.appId));
}

FirebaseStorage instanceStorageWindows() {
  return FirebaseStorage.instance;
}

Future<ListResultForAll> listAllWindows(Reference ref) async {
  Reference reference = ref;
  ListResult originalResult = await reference.listAll();
  return ListResultForAll(
      originalResult.items.map((e) => StorageRef.withReference(e)).toList(),
      originalResult.prefixes.map((e) => StorageRef.withReference(e)).toList());
}

Future<void> deleteFilesWindows(Reference ref) async {
  Reference reference = ref;
  ListResult result = await reference.listAll();
  for (var item in result.items) {
    await ref.child(item.name).delete();
  }
  var dirs = result.prefixes;
  for (var dir in dirs) {
    await deleteFilesWindows(reference.child(dir.name));
  }
}
