library firebase_for_all;

export 'functions.dart';
export 'firebase/firestore/bridge.dart';
export 'firebase/firestore/widgets.dart';
export 'firebase/firestore/models.dart';
export 'firebase/storage/bridge.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:get/get.dart';
import 'firebase/firestore/bridge.dart';
import 'firebase/firestore/windows.dart';
import 'firebase/storage/bridge.dart';
import 'firebase/storage/windows.dart';
import 'functions.dart';

class FirebaseCoreForAll {
  static Future<void> initializeApp(
      {String? name,
      required FirebaseOptions options,
      required bool firestore,
      required bool auth,
      required bool storage,
      required bool functions}) async {
    FirebaseControlPanel panel = Get.put(FirebaseControlPanel(
        firestore: firestore, storage: storage, functions: functions));
    panel.setOptions = options;
    panel.setName = name;
    if (isValid() || (!isValid() && (auth || functions))) {
      await Firebase.initializeApp(
          name: Get.find<FirebaseControlPanel>().name,
          options: Get.find<FirebaseControlPanel>().options);
    }
    if (!isValid() && firestore) {
      await initFirestoreWindows();
    }
    if (!isValid() && storage) {
      await initStorageWindows();
    }
  }
}

class FirestoreForAll {
  static FirestoreItem get instance {
    return Get.find<FirebaseControlPanel>().firestore!;
  }
}

class FirebaseStorageForAll {
  static FirebaseStorageItem get instance {
    return Get.find<FirebaseControlPanel>().storage!.instance()!;
  }
}

class FirebaseControlPanel extends GetxController {
  String? _name;
  FirebaseOptions? _options;
  FirestoreItem? _firestore;
  FirebaseStorageItem? _storage;

  FirebaseControlPanel(
      {required bool firestore,
      required bool storage,
      required bool functions}) {
    if (firestore) {
      _firestore = FirestoreItem();
    }
    if (storage) {
      _storage = FirebaseStorageItem();
    }
  }
  set setOptions(FirebaseOptions options) {
    _options = options;
  }

  set setName(String? name) {
    _name = name;
  }

  FirebaseOptions? get options => _options;

  FirestoreItem? get firestore => _firestore;
  FirebaseStorageItem? get storage => _storage;

  String? get name => _name;
}
