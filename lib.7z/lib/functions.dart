import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:http/http.dart';

import 'package:flutter/foundation.dart';

bool isMacos() {
  return Platform.isMacOS;
}

bool isWindows() {
  return Platform.isWindows;
}

bool isMobile() {
  return Platform.isIOS || Platform.isAndroid || Platform.isFuchsia;
}

bool isIOS() {
  return Platform.isIOS;
}

bool isAndroid() {
  return Platform.isAndroid;
}

bool isFuchsia() {
  return Platform.isFuchsia;
}

bool isValid() {
  return isMobile() || isMacos() || kIsWeb;
}

List<String> imgExt = [
  "apng",
  "avif",
  "gif",
  "jpg",
  "jpeg",
  "jfif",
  "pjpeg",
  "pjp",
  "png",
  "svg",
  "webp"
];
List<String> vidExt = [
  "webm",
  "mpg",
  "mp2",
  "mpeg",
  "mpe",
  "mpv",
  "ogg",
  "mp4",
  "m4p",
  "m4v",
  "avi",
  "wmv",
  "mov",
  "qt",
  "flv",
  "swf",
  "avchd"
];
List<String> audExt = [
  "m4a",
  "flac",
  "mp3",
  "wav",
  "wma",
  "aac",
];

enum TaskState {
  running,
  paused,
  success,
  cancelled,
  error;
}

class ProcessTask {
  int processed, total;
  late double percentage;
  Uint8List? bytes;
  TaskState state;
  ProcessTask(
      {required this.processed,
      required this.total,
      required this.state,
      this.bytes}) {
    percentage = processed / total;
  }
}

class DownloadTaskForAll {
  final _streamController = StreamController<ProcessTask>();
  StreamSubscription<dynamic>? _downloadingStream;
  ProcessTask? _finalTask;
  File? targetFile;

  DownloadTaskForAll({this.targetFile});
  Future<void> cancel() async {
    if (_downloadingStream != null) {
      await _downloadingStream!.cancel();
      if (_finalTask != null) {
        _finalTask!.state = TaskState.cancelled;
        _streamController.add(_finalTask!);
      } else {
        _streamController.add(
            ProcessTask(processed: 0, total: 0, state: TaskState.cancelled));
      }
    }
  }

  void pause() {
    if (_downloadingStream != null) {
      _downloadingStream!.pause();
      if (_finalTask != null) {
        _finalTask!.state = TaskState.paused;
        _streamController.add(_finalTask!);
      } else {
        _streamController
            .add(ProcessTask(processed: 0, total: 0, state: TaskState.paused));
      }
    }
  }

  void resume() {
    if (_downloadingStream != null) {
      _downloadingStream!.resume();
      if (_finalTask != null) {
        _finalTask!.state = TaskState.running;
        _streamController.add(_finalTask!);
      } else {
        _streamController
            .add(ProcessTask(processed: 0, total: 0, state: TaskState.running));
      }
    }
  }

  void addError(Object error, [StackTrace? stackTrace]) {
    _streamController.addError(error, stackTrace);
    if (_finalTask != null) {
      _finalTask!.state = TaskState.error;
      _streamController.add(_finalTask!);
    } else {
      _streamController
          .add(ProcessTask(processed: 0, total: 0, state: TaskState.error));
    }
  }

  void updateTask(ProcessTask task) {
    _streamController.add(task);
    _finalTask = task;
    if (targetFile != null && task.bytes != null) {
      targetFile!.writeAsBytesSync(task.bytes!);
    }
  }

  set setDownloadingStream(StreamSubscription<dynamic> stream) {
    _downloadingStream = stream;
  }

  Stream<ProcessTask> get stream => _streamController.stream;
}

Future<DownloadTaskForAll?> downloadFile(String url, {File? file}) async {
  try {
    var task = DownloadTaskForAll(targetFile: file);

    var httpClient = Client();
    var request = Request('GET', Uri.parse(url));
    var response = await httpClient.send(request);
    List<List<int>> chunks = [];
    int downloaded = 0;
    int sayac = 0;
    task.setDownloadingStream = response.stream.listen((List<int> chunk) {
      if (sayac % 500 == 0) {
        task.updateTask(ProcessTask(
            processed: downloaded,
            total: response.contentLength!,
            state: TaskState.running));
      }
      chunks.add(chunk);
      downloaded += chunk.length;
      sayac++;
    }, onDone: () {
      double percentage = (downloaded / response.contentLength!);
      Uint8List? bytes;
      if (percentage == 1) {
        bytes = Uint8List(response.contentLength!);
        int offset = 0;
        for (List<int> chunk in chunks) {
          bytes.setRange(offset, offset + chunk.length, chunk);
          offset += chunk.length;
        }
        task.updateTask(ProcessTask(
            processed: downloaded,
            total: response.contentLength!,
            state: TaskState.success,
            bytes: bytes));
      }
    }, onError: (e, stackTrace) {
      task.addError(e, stackTrace);
    });
    return task;
  } catch (e) {
    print(e);
    return null;
  }
}
